#!/usr/bin/env perl
use 5.010;
use strict;
use warnings;
use Git::Repository;

# local working dir/non-bare repositoru #
my $nb_repo = "/home/userrepo";
# remote repository #
my $b_repo = "https://github.com/demo/sample";

# create the Git object w.r.t local working dir #
my $git = Git::Repository->new( work_tree => $nb_repo );

# bring the remote refs up to date #
$git->run( 'remote', 'update' );

# get the status whetherthe master branch is ahead/behind  #
my $cmd = $git->command( status => '-uno' );
my $log = $cmd->stdout;

my $flag;
my $str = "Your branch is behind";
while(<$log>) {
   # if the origin/master is ahead, set falg #
   $flag = 1 if ($_ =~ /$str/);
}
$cmd->close;

if ($flag) {
  print "Found new commits in the repo : $b_repo \n";
  # update the local repo with the new commits # 
  $git->run( 'pull', 'origin/master' );
  
  my $clean = "mvn clean";
  # clean the old biuld objs #
  system($clean);

  my $test_cmd = "mvn test";
  # run the unit test #
  system($test_cmd);
}else{
  print "No new commits found in the remote repository : $b_repo \n";
}


